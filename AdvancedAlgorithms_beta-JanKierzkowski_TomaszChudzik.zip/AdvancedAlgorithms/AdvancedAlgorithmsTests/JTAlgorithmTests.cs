﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AdvancedAlgorithmsTests
{
    [TestClass]
    public class JTAlgorithmTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
