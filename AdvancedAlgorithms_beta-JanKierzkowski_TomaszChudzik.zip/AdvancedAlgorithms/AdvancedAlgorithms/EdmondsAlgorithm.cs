﻿using QuickGraph;
using System.Collections.Generic;

namespace AdvancedAlgorithms
{
    public static class EdmondsAlgorithm
    {
        public static List<Edge<int>> CalculateMaximumMatching(UndirectedGraph<int, Edge<int>> g)
        {
            return new List<Edge<int>>();
        }
    }
}
