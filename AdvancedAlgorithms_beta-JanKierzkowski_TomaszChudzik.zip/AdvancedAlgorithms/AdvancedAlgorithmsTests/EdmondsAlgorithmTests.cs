﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AdvancedAlgorithmsTests
{
    [TestClass]
    public class EdmondsAlgorithmTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
